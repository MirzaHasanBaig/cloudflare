Command:
helm install my-release --set Name=Name Domain=example.com Secret=secretssl Service=svctoattach ./ingress-ssl
